package cn.edu.thssdb.benchmark.config;

import cn.edu.thssdb.utils.Global;

public class Config {
  public static final String username = "root";
  public static final String password = "root";
  public static final String host = "127.0.0.1";
  public static final int port = 6667;
  public static final int SUCCESS_CODE = Global.SUCCESS_CODE;
}
